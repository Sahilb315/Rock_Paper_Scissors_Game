import java.util.Random;
import java.util.Scanner;

public class Rock_Paper_Scissors {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random rn = new Random();
        int uc;
        int cc;

            System.out.print("Enter 0 for Rock\nEnter 1 for Paper\nEnter 2 for Scissor\nEnter 3 to Exit\nOR Enter any number to exit the game\n\tYour Choice: ");
            uc= sc.nextInt();
            cc= rn.nextInt(3);
            System.out.println("Computer choice:"+cc);
            switch (uc) {
                case 0 -> {
                    switch (cc) {
                        case 1 -> System.out.println("You lose !!");
                        case 2 -> System.out.println("You win !!");
                        default -> System.out.println("Tie !!");
                    }
                }
                case 1 -> {
                    switch (cc) {
                        case 0 -> System.out.println("You win !!");
                        case 2 -> System.out.println("You lose !!");
                        default -> System.out.println("Tie !!");
                    }
                }
                case 2 -> {
                    switch (cc) {
                        case 0 -> System.out.println("You lose !!");
                        case 1 -> System.out.println("You win !!");
                        default -> System.out.println("Tie !!");
                    }
                }
                default -> System.exit(0);
            }


    }
}
