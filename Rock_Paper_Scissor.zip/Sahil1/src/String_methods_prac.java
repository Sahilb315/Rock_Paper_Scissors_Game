public class String_methods_prac {
    public static void main(String[] args) {

        String name = "Jack Parker";
        name = name.toLowerCase();
        System.out.println(name);

        System.out.println(name.replace(" ","_"));

        String name1 = "Dear <|name|>, Thanks a lot";
        System.out.println(name1.replace("<|name|>","Sahil"));

        String name2 = "Sahil  Bansal   315";
        System.out.println(name2.indexOf("   "));
        System.out.println(name2.indexOf("  "));

        System.out.println("\"Dear Harry,\nThis Java Course is nice. \n\tThanks\"");

    }
}
