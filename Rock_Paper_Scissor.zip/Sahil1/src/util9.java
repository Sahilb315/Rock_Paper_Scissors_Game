import java.util.Scanner;

public class util9 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("enter ur name");
        String name = scan.nextLine();

        System.out.println("Hello " + name + " have a good day");

    }
}
