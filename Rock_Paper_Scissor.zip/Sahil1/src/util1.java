import java.util.Scanner;
public class util1 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter Number :");
        int a = scan.nextInt();

        System.out.println("Enter Number :");
        int b = scan.nextInt();

        System.out.println("Enter Number :");
        int c = scan.nextInt();

        if((a>b)&&(a>c)){
            System.out.println("A is Greatest");
        }
        if((b>c)&&(b>a)){
            System.out.println("B is Greatest");
        }else{
            System.out.println("C is Greatest");
        }
    }

}
