public class if_else {
    public static void main(String[] args) {

         int age = 19;

         if(age>=18){
             System.out.println("u r eligible");
         }else{
             System.out.println("not eligible");
         }

    }
}
// Logical NOT
// input - number
// if (number){} else if (alpha){} else
// if (!number){break}
