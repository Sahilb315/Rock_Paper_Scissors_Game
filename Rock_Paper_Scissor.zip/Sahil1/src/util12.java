public class util12 {
    public static void main(String[] args) {

        float v = 2, u = 4, a = 6, s =8;

        float in = (v*v - u*u)/(2*a*s);

        System.out.println(in);
    }
}
