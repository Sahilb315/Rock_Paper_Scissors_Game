public class String_methods_manipulation {
    public static void main(String[] args) {

       String name = "sahil";
        System.out.println(name.length());
        System.out.println(name.toUpperCase());
        System.out.println(name.toUpperCase());

        String nontrimmedstring = "     Sahil     ";
        System.out.println(nontrimmedstring.trim());

        System.out.println(name.substring(2));
        System.out.println(name.substring(2,5));
        System.out.println(name.replace('s','m'));
        System.out.println(name.replace("sahil","shubh"));
        System.out.println(name.startsWith("a"));
        System.out.println(name.endsWith("hil"));
        System.out.println(name.charAt(3));
        System.out.println(name.indexOf('i'));
        System.out.println(name.indexOf("hil"));

        String name1 = "Sahil Bansal";
        System.out.println(name1.indexOf("a",2 ));

     System.out.println(name1.lastIndexOf("l",12));
     System.out.println(name.equals("sahil"));
     System.out.println(name.equalsIgnoreCase("SAHIL"));
     System.out.println(name.concat(" Bansal"));


     // Escape sequence characters
     System.out.println("Hlo i m \" sahil \" ");
     System.out.println("Hlo i m \n sahil  ");
     System.out.println("Hlo i m \t sahil  ");

    }
}
