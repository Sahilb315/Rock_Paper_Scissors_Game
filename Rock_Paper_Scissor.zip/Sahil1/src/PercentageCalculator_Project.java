import java.util.Scanner;
public class PercentageCalculator_Project {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);


        System.out.println("Subject 1 marks :");
        int a = scan.nextInt();

        while(a>100){
            System.out.println("Enter in the range of 0-100");
            a = scan.nextInt();
        }

        System.out.println("Subject 2 marks :");
        int b = scan.nextInt(); //90 //110

        while(b>100) {
            System.out.println("Enter in the range of 0-100");
            b = scan.nextInt();
        }

        System.out.println("Subject 3 marks :");
        int c = scan.nextInt();


        while(c>100){
            System.out.println("Enter in the range of 0-100");
            c = scan.nextInt();
        }

        System.out.println("Subject 4 marks :");
        int d = scan.nextInt();


        while(d>100){
            System.out.println("Enter in the range of 0-100");
            d = scan.nextInt();
        }

        System.out.println("Subject 5 marks :");
        int e = scan.nextInt();


        while(e>100){
            System.out.println("Enter in the range of 0-100");
            e = scan.nextInt();
        }


        int sum = a+b+c+d+e;
        System.out.println("Total Marks :" + sum );

        int per = sum*100/500;

        System.out.println("Percentage :" + per);




    }
}
