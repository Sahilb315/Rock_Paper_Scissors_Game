import java.util.Scanner;
import java.util.Random;

public class Rock_Paper_Scissors_Projectt {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Random rand  = new Random();

        System.out.println("Enter 0 for rock\nEnter 1 for Paper\nEnter 2 for Scissors\nEnter 3 for Exit the game\nEnter Your Choice");
        int user =0;
        int computer=0;
        for(int a = 0;a<5;a++) {

            int ui = scan.nextInt();
            int ci = rand.nextInt(3);

            if(ui==3){System.exit(0);}

            System.out.println("Computer Choice " + ci);

            switch (ui) {
                case 0 -> {
                    switch (ci) {
                        case 1 -> System.out.println("You lose " + computer++);
                        case 2 -> System.out.println("You win " + user++);
                        default -> System.out.println("tie");
                    }
                }
                case 1 -> {
                    switch (ci) {
                        case 0 -> System.out.println("You win "+ user++);
                        case 2 -> System.out.println("You lose "+ computer++);
                        default -> System.out.println("Tie");
                    }
                }
                case 2 -> {
                    switch (ci) {
                        case 0 -> System.out.println("You lose "+ computer++);
                        case 1 -> System.out.println("You win " + user++);
                        default -> System.out.println("Tie");
                    }
                }

            }
        }

        System.out.println("user wins ="+user+" and computer wins ="+computer);
    }
}
