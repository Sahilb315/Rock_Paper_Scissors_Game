import java.util.Scanner;

public class util4 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter Number");
        int a = scan.nextInt();

        if((a%5==0)&&(a%11==0)){
            System.out.println("It is divisible ");
        }else{
            System.out.println("It is not divisible");
        }

    }
}
