import java.util.Scanner;

public class util3 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("enter Number : ");
        int a = scan.nextInt();

        if(a>0) {
            System.out.println("Numnber is Positive");
        }else if(a<0) {
            System.out.println("Number is Negative");
        }
        else if(a==0){
            System.out.println("Zero");
        }

    }
}
