import java.sql.SQLOutput;
import java.util.Scanner;
public class while_Loop {
    public static void main(String[] args) {

     /*   int var = 2;
        switch(var){
            case 1:
                System.out.println("good");
                break;
            case 2:
                System.out.println("Better");
                break;
            case 3:
                System.out.println("Best");
                break;
            default:
                System.out.println("Invalid");*/
       /* int m = 1;
        int x = 19;
        if(m==0){
        x=x+2;
            System.out.println("X=" + x);
        } else if (m==1) {
            x=x+4;
            System.out.println("X="+x);
        } else if (m==2) {
            x=x+6;
            System.out.println("X="+x);
        }else{
            System.out.println("Invalid");
        }*/

      /*  Scanner scan = new Scanner(System.in);
        System.out.println("Enter the number :");
        int a = scan.nextInt();

        if(a%2==0 && a%3==0){
            System.out.println("This number is divisible by both");
        }else{
            System.out.println("This number is not divisible");
        }
*/
/*
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter your number ");
        int a = scan.nextInt();

        if(a==0){
            System.out.println("Number is zero");
        }else if(a%2==0){
            System.out.println("Number is even");
        }else{
            System.out.println("Number is Odd");
        }*/


       /* Scanner scan = new Scanner(System.in);
        System.out.println("Enter Digit");
        int a = scan.nextInt();

        if(a>=0 && a<=9){
            System.out.println("Number is single digit");
        } else if (a>=10 && a<=99) {
            System.out.println("Number is double digit");
        }else{
            System.out.println("Number is more then 2 digits");
        }*/


       /* Scanner scan = new Scanner(System.in);
        System.out.println("enter ur 1st digit:");
        int a = scan.nextInt();

        System.out.println("Enter ur 2nd digit:");
        int b = scan.nextInt();

        System.out.println("Enter ur 3rd digit:");
        int c = scan.nextInt();

        if(a>b && a>c){
            System.out.println("a is greastes");
        } else if (b>a && b>c) {
            System.out.println("b is greatest");
        }else{
            System.out.println("c is greatest");
        }
*/


       /* Scanner scan = new Scanner(System.in);

        int sq =0;
        int cube =0;

        System.out.println("Enter 1st number");
        int a = scan.nextInt();

        System.out.println("Enter ur 2nd number");
        int b = scan.nextInt();

        if(a>b){
            sq= b*b;
            cube = a*a*a;
            System.out.println(sq +"\n"+ cube);
        }else if (b>a){
            sq= a*a;
            cube = b*b*b;
            System.out.println(sq +"\n"+ cube);

        }else{
            System.out.println("Both Numbers are equal");
        }


        Scanner scan = new Scanner(System.in);

        System.out.println("Enter Any Number");
        int a = scan.nextInt();

        if(a>0 && a%2==0){
            System.out.println("The number is Positive even. And 3 succeeding numbers are: " + (a+2)+" "+(a+4)+" "+(a+6));
        } else if (a<0 && a%3==0) {
            System.out.println("this number is Negative odd. And 3 preceding numbers are: " + (a-2)+" "+(a-4)+" "+(a-6));
        }else{
            System.out.println("Number is neither a positive even nor a negative odd");
        }


        Scanner scan = new Scanner(System.in);

        int sum=0;
        int product=0;

        System.out.println("Enter 1st number");
        int a = scan.nextInt();

        System.out.println("enter 2nd number");
        int b = scan.nextInt();

        System.out.println("enter 3rd number");
        int c = scan.nextInt();

        System.out.println("enter char");
        char d = scan.next().charAt(0);

        if(d=='s'){
            sum = a+b+c;
            System.out.println("Sum of numbers is :" + sum);
        } else if (d=='p') {
            product= a*b*c;
            System.out.println("Product of numbers is :" + product);
        }else{
            System.out.println("The aplhabet is: " + d);
        }


        Scanner scan = new Scanner(System.in);
        System.out.println("enter the number number you want to root :");

        Double a = Math.sqrt(scan.nextDouble());
        System.out.println(a);

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter 1st number");
        int a = scan.nextInt();

        System.out.println("Enter 2nd number");
        int b = scan.nextInt();

        System.out.println("Enter 3rd number");
        int c = scan.nextInt();

        if(b>a && b<c){
            System.out.println("B is Second Smallest number");
        }else{
            System.out.println("Invalid");
        }
*/
    /*    int a=0,b=1,c,i;
        System.out.print(a+" "+b+" ");
        for (i=3;i<=20;i++){

            c = a+b;
            System.out.print(c+ " ");
            a=b;
            b=c;

        int n ;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the value of n: ");
        n = sc.nextInt();
        System.out.println ("The all Factors of given no. "+n+" is");
        for(int i = 1;i<= n;i++)
        {
            if(n%i == 0)
                System.out.println (i);
        }

         int reversenum = 0, digit, num = 17263;
         while(num>0){
             digit = num%10;
             reversenum = reversenum*10+digit;
             num = num/10;
         }
        System.out.println(reversenum);


        Scanner scan = new Scanner(System.in);

        System.out.println("enter number :");
        int a = scan.nextInt();


        int num1 , num2 ;
        System.out.print("Enter any two number:");
        Scanner sc = new Scanner(System.in);
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        while (num1 != num2) {
            if(num1 > num2) {
                num1 = num1 - num2;
            }
            else
                num2 = num2 - num1;
        }
        System.out.printf("GCD of given numbers is: "+num2);
*/
     /* for(int i = 0;i<20;i++){
          if(i>=2 && i<=5){
              System.out.println("Ending");
              continue;
          }
          System.out.println(i);
          System.out.println("Java");
------------------------------------------------------
       for(int i =5;i>0;i--){
           for (int j=0;j<i;j++){
               System.out.print("*");
           }
           System.out.println("");
       }
*/

      /* int sum = 0;
       for(int i=0;i<=5;i++){
           sum = sum+ (2*i-1);
       }
        System.out.println(sum);
*/
//     3 5 7 9

    /*    for (int i = 0; i<5; i++) {
            for (int j = 0; j<=i; j++) {
                System.out.print("*");
            }
            System.out.println("");
        }*/

       /* int a = 10,multi;
        for(int i=1;i<=10;i++) {
            System.out.printf("%d * %d = %d\n", a, i, a * i);
        }


         int a = 10,multi;
        for(int i=10;i>=1;i--){
            System.out.printf("%d * %d = %d\n", a, i, a*i  );
        }

        int fact = 1;
        int n = 5;
        for(int i=1;i<=n;i++){
            fact *= i;

        }
        System.out.println(fact);
*/

    /*   int i = 5, a=1;
       while(a<=i){
           System.out.println("*");
           a++;
       }

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter 0 or 1 :");
        int a = scan.nextInt();

        if(a==1){
            System.out.println("Enter ur Sub marks :");
            int b = scan.nextInt();



            if(b>=90){
                System.out.println("This is good");
            } else if (b<89 && b>=60) {
                System.out.println("This is also good");
            }else{
                System.out.println("This is Good as well");
            }

        }else{
            System.out.println("Invalid");
        }


        for(int i =5;i>0;i--){
            for (int j=0;j<i;j++){
                System.out.print("*");
            }
            System.out.println("");
        }


        int n = 4;
        for(int i = 1;i<=n;i++){
            for(int j=1;j<=n-i;j++){
                System.out.print(" ");
            }
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }

        int n=5;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
                System.out.print(j);
            }
            System.out.println();
        }
*/
       /* int n=5;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n-i;j++){
                System.out.print(" ");
            }
            for(int j=1;j<=i;j++){
                System.out.print(j);
            }
            System.out.println();
        }*/
//        int n = 5;
//        for(int i = 1;i<=n;i++){
//            for(int j=1;j<=n-i;j++){
//                System.out.print(" ");
//            }
//            for(int j=1;j<=i;j++){
//                System.out.print("j");
//            }
//            System.out.println();
//        }

       /* int n=5;
        // outer loop
        for(int i=1;i<=n;i++){
            //inner loop
            for(int j=1;j<=n-i+1;j++){
                System.out.print(j);
            }
            System.out.println();
        }*/
/*
        int n=3;
        int num = 1;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
                System.out.print(num);
                num++;
            }
            System.out.println();
        }
*/

        /*int n =5;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
                int sum = i+j;
                if(sum%2==0){
                    System.out.print("1 ");
                }else{
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }*/

//        int n=4;
//        int m=5;
//        for(int i=1;i<=n;i++){
//            for(int j=1;j<=m;j++){
//                System.out.print("*");
//            }
//            System.out.println();
//        }
//
//        int n=1;
//        for(int i=4;i>=n;i--){
//            for(int j=1;j<=i;j++){
//                System.out.print("*");
//            }
//            System.out.println();
//        }

//        int n=5;
//        for(int i=1;i<=n;i++){
//            for(int j=1;j<=n-i;j++){
//                System.out.print(" ");
//            }
//            for(int j=1;j<=n;j++){
//                System.out.print("*");
//            }
//            System.out.println();
//        }
        int n=4;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n-i;j++){
                System.out.print(" ");
            }
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
