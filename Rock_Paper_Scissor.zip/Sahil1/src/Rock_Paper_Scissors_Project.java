import java.util.Scanner;
import java.util.Random;

public class Rock_Paper_Scissors_Project {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Random rand = new Random();


        System.out.println("Enter 0 for Rock \nEnter 1 for Paper\nEnter 2 for Scissors \n Your Choice: ");
        int  up = scan.nextInt();

        int  cp = rand.nextInt(2);
        System.out.println("Computer Choice: " + cp);

        switch(up){
            case 0->{
                switch(cp){
                    case 1->
                        System.out.println("You lose");
                    case 2->
                        System.out.println("You win");
                    default ->
                            System.out.println("Tie");
                }
            }
            case 1->{
                switch(cp){
                    case 0->
                        System.out.println("You win");
                    case 2->
                        System.out.println("You lose");
                    default->
                        System.out.println("Tie");
                }
            }
            case 2->{
                switch(cp){
                    case 0->
                        System.out.println("You lose");
                    case 1->
                        System.out.println("You win");
                    default->
                        System.out.println("Tie");
                }
            }
        }

    }
}
