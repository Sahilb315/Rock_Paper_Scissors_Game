public class util11 {
    public static void main(String[] args) {

        char grade = 'B';
        grade = (char)(grade + 8);
        System.out.println("Grade after Adding " + grade);

        grade = (char)(grade - 8);
        System.out.println("Grade after Decrypting " + grade);

    }
}
