import java.util.Scanner;
public class util7 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter");
        char ch = scan.next().charAt(0);

        if((ch>='a')&&(ch<='z') || (ch>='A')&&(ch<='Z')){
            System.out.println("It is a alphabet");
        }else{
            System.out.println("It is not a alphabet ");
        }
    }
}
