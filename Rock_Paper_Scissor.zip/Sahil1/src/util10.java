import java.util.Scanner;
public class util10 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter ur gender");
        char a = scan.next().charAt(0);

        if(a=='M') {

            for (int number = 1; number <= 5; ++number) {
                System.out.println(number);
            }
        }else{
            System.out.println("Invalid");
        }
    }
}
