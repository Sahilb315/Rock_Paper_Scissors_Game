public class for_loop {
    public static void main(String[] args) {
/*
        for(int a = 0;a<=5;a++){
            System.out.println(a);
        }*/
        int b = 0;
       while(b<=5){
           System.out.println(b++);
        }
    }
}
