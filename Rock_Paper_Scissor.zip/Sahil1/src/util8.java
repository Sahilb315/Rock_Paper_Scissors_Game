import java.util.Scanner;
public class util8 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter 1st  number");
        int a = scan.nextInt();

        System.out.println("Enter 2nd number");
        int b = scan.nextInt();

        System.out.println("Enter 3rd number");
        int c = scan.nextInt();

        int sum = a+b+c;
        System.out.println(sum);

    }
}
