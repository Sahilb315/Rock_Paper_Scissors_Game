import java.util.Scanner;

public class util5 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter Number :");
        int a = scan.nextInt();

        if(a%2==0){
            System.out.println("Number is Even");
        }else{
            System.out.println("Number is Odd");
        }

    }
}
